package com.interswitchng.smartpos.activities

import android.support.test.runner.AndroidJUnit4
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SettingsInstrumentationTests {

}