package com.interswitchng.smartpos.shared.models.email

data class Email(
        val email: String,
        val name: String? = null
)