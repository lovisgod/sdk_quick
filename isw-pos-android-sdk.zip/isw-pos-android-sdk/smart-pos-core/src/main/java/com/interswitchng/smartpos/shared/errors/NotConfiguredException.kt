package com.interswitchng.smartpos.shared.errors

class NotConfiguredException: Exception("POS Device has not been configured")