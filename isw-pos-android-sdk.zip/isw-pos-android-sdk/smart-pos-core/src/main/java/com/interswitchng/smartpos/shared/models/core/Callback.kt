package com.interswitchng.smartpos.shared.models.core


typealias Callback<R> = (response: R?, t: Throwable?) -> Unit