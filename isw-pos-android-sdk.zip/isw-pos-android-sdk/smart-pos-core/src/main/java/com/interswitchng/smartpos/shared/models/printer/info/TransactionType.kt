package com.interswitchng.smartpos.shared.models.printer.info

internal enum class TransactionType {
    Purchase,
}