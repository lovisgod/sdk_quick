package com.interswitchng.smartpos.modules.authentication

import android.arch.lifecycle.ViewModel

internal class AuthenticationViewModel : ViewModel() {


}