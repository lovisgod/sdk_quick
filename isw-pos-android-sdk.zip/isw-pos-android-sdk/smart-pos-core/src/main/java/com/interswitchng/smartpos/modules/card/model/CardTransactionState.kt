package com.interswitchng.smartpos.modules.card.model

enum class CardTransactionState {
    ShowInsertCard,
    EnterPin,
    Default
}