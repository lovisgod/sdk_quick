package com.interswitchng.smartpos.activities

import org.junit.Test

class UssdActivityTests {

    @Test
    fun `should load banks in spinner once activity is created` () {


    }
}