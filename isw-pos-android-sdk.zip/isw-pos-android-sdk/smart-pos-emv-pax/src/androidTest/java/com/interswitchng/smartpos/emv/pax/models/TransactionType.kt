package com.interswitchng.smartpos.emv.pax.models

enum class TransactionType {
    Purchase,
}