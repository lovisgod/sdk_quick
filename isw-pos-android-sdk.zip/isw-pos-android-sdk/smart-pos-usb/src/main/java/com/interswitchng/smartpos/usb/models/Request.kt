package com.interswitchng.smartpos.usb.models

data class Request(internal val amount: Int)